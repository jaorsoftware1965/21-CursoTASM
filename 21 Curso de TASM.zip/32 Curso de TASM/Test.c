#include "stdio.h"

int main()
{
	printf("Hola Mundo");
	return 0;
}